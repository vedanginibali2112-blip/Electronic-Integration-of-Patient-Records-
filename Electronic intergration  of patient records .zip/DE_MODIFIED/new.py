import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn import svm
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Load CSV file (replace with your actual path)
data = pd.read_csv("IndianDiabeticPatients_updated_with_BMI_BP.csv")

# Data Preprocessing and Cleaning

# Step 1: Handling Missing Values
# Drop rows with NaN values in the target column 'DiabetesType'
data_filtered = data[['Age', 'Gender', 'HbA1c', 'BloodGlucose', 'BMI', 'SystolicBP', 'DiastolicBP', 'FamilyHistory', 'DiabetesType']]
data_filtered = data_filtered.dropna(subset=['DiabetesType'])

# Fill missing numerical values with the mean of the respective column
num_cols = ['Age', 'HbA1c', 'BloodGlucose', 'BMI']
data_filtered[num_cols] = data_filtered[num_cols].fillna(data_filtered[num_cols].mean())

# Step 2: Encoding Categorical Variables
gender_map = {'Male': 1, 'Female': 0}
family_history_map = {'Yes': 1, 'No': 0}
data_filtered['Gender'] = data_filtered['Gender'].map(gender_map)
data_filtered['FamilyHistory'] = data_filtered['FamilyHistory'].map(family_history_map)

# Map target variable to numeric values
diabetes_type_map = {'Non-Diabetic': 0, 'Type1': 1, 'Type2': 2}
data_filtered['DiabetesType'] = data_filtered['DiabetesType'].map(diabetes_type_map)

# Step 3: Normalization (Scaling Numerical Values)
scaler = StandardScaler()
data_filtered[num_cols] = scaler.fit_transform(data_filtered[num_cols])

# Step 4: Splitting Data into Features and Target
X = data_filtered[['Age', 'Gender', 'HbA1c', 'BloodGlucose', 'BMI', 'SystolicBP', 'DiastolicBP', 'FamilyHistory']]
y = data_filtered['DiabetesType']

# Split data for training and testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Pre-diabetes logic
def check_prediabetes(hba1c, glucose, glucose_test_type="Fasting"):
    prediabetes_hba1c = 5.7 <= hba1c <= 6.4
    prediabetes_glucose = (glucose_test_type == 'Fasting') and (100 <= glucose <= 125)
    if prediabetes_hba1c or prediabetes_glucose:
        return True
    return False

# Tkinter UI to input values and predict
def predict_diabetes():
    try:
        # Get input values from the user
        age = float(entry_age.get())
        gender = entry_gender.get()
        hba1c = float(entry_hba1c.get())
        glucose = float(entry_glucose.get())
        bmi = float(entry_bmi.get())
        systolic_bp = float(entry_sbp.get())
        diastolic_bp = float(entry_dbp.get())
        family_history = entry_family_history.get()

        # Map categorical inputs
        gender_encoded = gender_map[gender]  # Convert gender to numeric
        family_history_encoded = family_history_map[family_history]  # Convert family history to numeric

        # Prepare input for prediction
        input_data = [[age, gender_encoded, hba1c, glucose, bmi, systolic_bp, diastolic_bp, family_history_encoded]]

        # Predict using selected model
        if model_choice.get() == "XGBoost":
            model = XGBClassifier()
        else:
            model = svm.SVC(probability=True)

        # Train model and predict
        model.fit(X_train, y_train)
        prediction = model.predict(input_data)
        accuracy = accuracy_score(y_test, model.predict(X_test))

        # Show result
        result_map = {0: "Non-Diabetic", 1: "Type 1 Diabetic", 2: "Type 2 Diabetic"}
        result = result_map[prediction[0]]

        # Check for prediabetes condition
        is_prediabetic = check_prediabetes(hba1c, glucose)

        # Show prediction result with additional analysis
        prediabetes_msg = "Note: The patient might be prediabetic." if is_prediabetic else ""
        messagebox.showinfo("Prediction", f"{result}\nAccuracy: {accuracy:.2f}\n{prediabetes_msg}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Create the Tkinter window
window = tk.Tk()
window.title("Diabetes Prediction")

# Input fields for the model
ttk.Label(window, text="Age:").grid(row=0, column=0)
entry_age = ttk.Entry(window)
entry_age.grid(row=0, column=1)

ttk.Label(window, text="Gender (Male/Female):").grid(row=1, column=0)
entry_gender = ttk.Entry(window)
entry_gender.grid(row=1, column=1)

ttk.Label(window, text="HbA1c:").grid(row=2, column=0)
entry_hba1c = ttk.Entry(window)
entry_hba1c.grid(row=2, column=1)

ttk.Label(window, text="Blood Glucose:").grid(row=3, column=0)
entry_glucose = ttk.Entry(window)
entry_glucose.grid(row=3, column=1)

ttk.Label(window, text="BMI:").grid(row=4, column=0)
entry_bmi = ttk.Entry(window)
entry_bmi.grid(row=4, column=1)

ttk.Label(window, text="Systolic BP:").grid(row=5, column=0)
entry_sbp = ttk.Entry(window)
entry_sbp.grid(row=5, column=1)

ttk.Label(window, text="Diastolic BP:").grid(row=6, column=0)
entry_dbp = ttk.Entry(window)
entry_dbp.grid(row=6, column=1)

ttk.Label(window, text="Family History (Yes/No):").grid(row=7, column=0)
entry_family_history = ttk.Entry(window)
entry_family_history.grid(row=7, column=1)

# Dropdown for selecting model
model_choice = tk.StringVar(value="XGBoost")
ttk.Label(window, text="Choose Model:").grid(row=8, column=0)
ttk.OptionMenu(window, model_choice, "XGBoost", "SVM").grid(row=8, column=1)

# Predict button
ttk.Button(window, text="Predict", command=predict_diabetes).grid(row=9, column=1)

# Visualization of prediabetes data
def show_visualization():
    plt.figure(figsize=(8,6))
    sns.boxplot(x='DiabetesType', y='HbA1c', data=data_filtered)
    plt.title("HbA1c Distribution by Diabetes Type")
    plt.show()

ttk.Button(window, text="Show HbA1c Visualization", command=show_visualization).grid(row=10, column=1)

# Additional visualization for feature correlation
def show_correlation():
    plt.figure(figsize=(10,8))
    sns.heatmap(data_filtered.corr(), annot=True, cmap='coolwarm', fmt='.2f')
    plt.title("Correlation Between Features")
    plt.show()

ttk.Button(window, text="Show Feature Correlation", command=show_correlation).grid(row=11, column=1)

# Show blood glucose distribution
def show_glucose_distribution():
    plt.figure(figsize=(8,6))
    sns.boxplot(x='DiabetesType', y='BloodGlucose', data=data_filtered)
    plt.title("Blood Glucose Distribution by Diabetes Type")
    plt.show()

ttk.Button(window, text="Show Blood Glucose Visualization", command=show_glucose_distribution).grid(row=12, column=1)

window.mainloop()
